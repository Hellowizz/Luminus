
public abstract class Agent { 

	World _world;
		
	int 	_x;
	int 	_y;
	int 	_orient;
	int     _bloque;
	boolean _alive;
	public boolean _etat;
	
	
	public Agent( int __x, int __y, World __w )
	{
		_x = __x;
		_y = __y;
		_world = __w;

		_orient = 0;
		_etat = true;
	}
	
	abstract public boolean bloque ();
	
	abstract public void step();
	
	public int getx(){
		return _x;
	}
	
	public boolean getEtat(){
		return _etat;
	}

	public int gety(){
		return _y;
	}
	
	public void deplacement(){
		switch (_orient) {
		case 0: // nord
			if (_y - 1 >= 0 && 
					_world.tabEnvCour[_x][_y - 1] != 1 && 
					_world.tabEnvCour[_x][_y - 1] != 5 &&
					_world.tabEnvCour[_x][_y - 1] < 14 &&
					_bloque == 0) {
				_y = _y - 1;
			}
			break;
		case 1: // est
			if (_x + 1 < _world.getWidth()&& 
					_world.tabEnvCour[_x + 1][_y] != 1 && 
					_world.tabEnvCour[_x + 1][_y] != 5 &&
					_world.tabEnvCour[_x + 1][_y] < 14 &&
					_bloque == 0) {
				_x = _x + 1;
			}
			break;
		case 2: // sud
			if (_y + 1 < _world.getHeight() && 
					_world.tabEnvCour[_x][_y + 1] != 1 && 
					_world.tabEnvCour[_x][_y + 1] != 5 &&
					_world.tabEnvCour[_x][_y + 1] < 14 &&
					_bloque == 0) {
				_y = _y + 1;
			}
			break;
		case 3: // ouest
			if (_x - 1 >= 0 && 
					_world.tabEnvCour[_x - 1][_y] != 1 && 
					_world.tabEnvCour[_x - 1][_y] != 5 &&
					_world.tabEnvCour[_x - 1][_y] < 14 &&
					_bloque == 0) {
				_x = _x - 1;
			}
			break;
		}
		
	}
	
}
