import java.util.Timer;
import java.util.TimerTask;

public class Ombrinthes extends Agent {

	int _digestion;
	private static int compteur = 0;
	private static int compteurTotal = 0;
	int numero;

	// si l'ombrinthe est en train de manger Lum
	boolean mange_luminus;

	// vrai si l'ombrinthe et en digestion et qu'elle a trouve un chemin jusqu'au trou noir
	boolean chemin_trouve_trounoir = false;

	boolean chemin_trouve_lanterne = false;
	Lanterne l_marquee = null;

	boolean chemin_trouve_luminus = false;
	int traque = 0;

	boolean pas_de_chemin = false;

	// le chemin construit de l'ombrinthe
	boolean[][] chemin;

	public Ombrinthes(World __w) {
		super(__w.trou_noir.getx(), __w.trou_noir.gety(), __w);
		_digestion = 0;
		compteur++;
		compteurTotal ++;
		numero = compteur;
		_alive = true;
		_world = __w;
		mange_luminus = false;
		_world.agents[this._x][this._y] = 2;
		chemin = new boolean[_world.width][_world.height];
	}

	// PARTIE OMBRINTHE - LUMINUS

	public boolean cherche_Luminus() {

		int rayon_detection = 5;

		int x_min = _x - rayon_detection;
		int x_max = _x + rayon_detection;

		int y_min = _y - rayon_detection;
		int y_max = _y + rayon_detection;

		if (_x >= _world.getWidth() - rayon_detection ) {
			x_max = _x;
		}

		if (_x >= 0 && _x < rayon_detection ) {
			x_min = 0;
		}

		if (_y >= _world.getHeight() - rayon_detection ) {
			y_max = _y;
		}
		if (_y >= 0 && _y < rayon_detection) {
			y_min = 0;
		}

		for (int i = x_min; i <= x_max; i++) {
			for (int j = y_min; j <= y_max; j++) {
				if (_world.agents[i][j] == 1) {
					return true;
				}
			}
		}
		return false;
	}

	public void chemin_Luminus() {
		Astar a = new Astar(_world,new Point(_x,_y),new Point(_world.luminus._x,_world.luminus._y));
		chemin = a.astar_final();
		if ( chemin != null ){
			chemin_trouve_luminus = true;
		}
		traque++;
		if ( traque == 8 ){
			traque = 0;
		}
	}

	public boolean bloque (){
		if(_world.tabEnvCour[_x][_y] == 6 && _bloque==0){
			_bloque=5;
			return true;
		}
		return false;
	}

	// PARTIE OMBRINTHE - LANTERNE

	public double distance_directe(int x,int y){
		return Math.sqrt((double)( ((_x - x)*(_x - x)) + ((_y - y)*(_y - y)) ));
	}

	public void cherche_lanterne_allumee(){
		// Prend la lanterne allumee non marquee la plus proche
		if ( !_world.lanterneListe.isEmpty() ){
			for ( int i = 0 ; i < _world.lanterneListe.size() ; i++ ){
				if ( _world.tabEnvCour[_world.lanterneListe.get(i).x][_world.lanterneListe.get(i).y] == 2 
						&& !_world.lanterneListe.get(i).marquee_par_ombrinthe ){
					if ( l_marquee == null ){
						l_marquee = _world.lanterneListe.get(i);
					}
					else {
						if ( distance_directe(l_marquee.x,l_marquee.y) < distance_directe(_world.lanterneListe.get(i).x,_world.lanterneListe.get(i).y)){
							l_marquee = _world.lanterneListe.get(i);
						}
					}
				}
			}
			if ( l_marquee != null ) {
				l_marquee.marquee_par_ombrinthe = true;
			}
		}
	}

	public void chemin_lanterne() {

		if ( l_marquee == null ){
			System.out.println("Pas de lanterne allumee non marquee trouvee");
		}
		else{
			if ( _world.tabEnvCour[l_marquee.x][l_marquee.y] == 3){
				l_marquee.marquee_par_ombrinthe = false;
				l_marquee = null;
			}
			else{
				Astar a = new Astar(_world,new Point(_x,_y),new Point(l_marquee.x,l_marquee.y));
				chemin = a.astar_final();
				if ( chemin != null ){
					chemin_trouve_lanterne = true;
				}
			}
		}
	}

	public void surLanterne(){
		if(_x == l_marquee.x && _y == l_marquee.y ){
			chemin_trouve_lanterne = false;
			chemin[_x][_y] = false;
			l_marquee.marquee_par_ombrinthe = false;
			mange_lanterne();
		}
	}

	public void mange_lanterne() {
		if (_digestion == 0) {
			if (_world.tabEnvCour[_x][_y] == 2) {
				_world.tabEnvCour[_x][_y] = 3;
				_world.tabEnvNouv[_x][_y] = 3;
				_digestion = 30;
			}
		}
	}

	// PARTIE OMBRINTHE - TROU NOIR 
	public void chemin_TrouNoir(){
		//algo A star pour aller vers le trou noir
		Astar a = new Astar(_world,new Point(_x,_y),new Point(_world.trou_noir.getx(),_world.trou_noir.gety()));
		//reinitialiser_chemin();
		chemin = a.astar_final();
		if ( chemin != null ){
			chemin_trouve_trounoir = true;
		}
	}

	public void surTrouNoir(){
		if(_x == _world.trou_noir.getx() && _y == _world.trou_noir.gety()){
			this._digestion = 0;
			chemin_trouve_trounoir = false;
			chemin[_x][_y] = false;
		}
		else{
			_digestion--;
		}
	}

	// ----------------------------------------------------

	public void orientation(boolean[][] chemin){
		//	Fait le deplacement en suivant le chemin construit		
		if ( chemin != null ){
			if ( _x - 1 >= 0 && chemin[_x - 1][_y] ){
				_orient = 3;
			}
			if ( _y - 1 >= 0 && chemin[_x][_y - 1] ){
				_orient = 0;
			}
			if ( _y + 1 < _world.getHeight() && chemin[_x][_y + 1] ){
				_orient = 2;
			}
			if ( _x + 1 < _world.getWidth() && chemin[_x + 1][_y] ){
				_orient = 1;
			}
			chemin[_x][_y] = false;
		}
	}


	public static int getCompteurTotal(){
		return compteurTotal;
	}

	public void die() {
		_alive = false;
		compteurTotal --;
		_world.luminus.mange_ombrinthe = true;
		Timer timer_o = new Timer();
		TimerTask task_o = new TimerTask() {
			public void run() {
				System.out.println("Vous venez de manger une Ombrinthe, etait-ce bon ? \n");
				_world.luminus.mange_ombrinthe = false;
			}
		};

		timer_o.schedule(task_o, 500);
	}

	public void kill_or_die() {
		// si l'ombrinthe va sur une case occupee par Luminus
		if (_world.agents[_x][_y] == 1) {
			if (_digestion == 0) {
				mange_luminus = true;
				_world.luminus.die();
			} else {
				// Luminus doit manger l'ombrinthe
				die();
			}
		}
	}

	public void step() {
		// met a jour l'ombrinthe

		// mange_lum permet d'eviter le deplacement quand l'ombrinthe mange Luminus
		if (mange_luminus == false) {

			_world.agents[_x][_y] = 0;

			if ( _bloque == 0 ) {

				// Calcul des chemins selon les objectifs

				if (this._digestion != 0) {
					chemin_trouve_lanterne = false;
					chemin_trouve_luminus = false;
					surTrouNoir();
					chemin_TrouNoir();
				}

				else { 
					// Priorite 1 : Detection de Luminus
					if ( traque > 0 && traque < 8 ) {
						chemin_trouve_lanterne = false;
						chemin_Luminus();
					}
					else {
						if ( cherche_Luminus() ){
							System.out.println("Vous etes detecte par une Ombrinthe. \n Courez ! \n");
							chemin_Luminus();
						}
						else{
							// Priorite 2 : Chercher une lanterne
							chemin_trouve_luminus = false;
							if ( l_marquee == null ){
								cherche_lanterne_allumee();
							}
							else{
								surLanterne();
								chemin_lanterne();
							}
						}
					}
				}

				if ( chemin_trouve_trounoir || chemin_trouve_lanterne || chemin_trouve_luminus){
					orientation(chemin);
				}
				else{
					pas_de_chemin = true;
					int newDirection = (int) (Math.random() * 4);
					_orient = newDirection;
				}

				if ( chemin != null || pas_de_chemin ){
					deplacement();
				}
				
				pas_de_chemin = false;
				mange_lanterne();
				bloque();
			}

			else{ // bloque != 0
				_bloque --;
				traque++;
			}

			kill_or_die();
			_world.agents[_x][_y] = 2;
		}
	}
}

