import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Timer;
import java.util.TimerTask;

public class Luminus extends Agent implements KeyListener {
	Sprite sp;
	
	// permet d'empecher les deplacement lorsqu'une ombrinthe est mangee 
	boolean mange_ombrinthe;

	public Luminus(World __w, Sprite s) {
		super(__w.lanterneListe.get(0).getx(), __w.lanterneListe.get(0).gety(),__w);
		_alive = true;
		_world = __w;
		_world.agents[this._x][this._y] = 1;
		sp = s;
		mange_ombrinthe = false;
	}
	
	public void keyPressed(KeyEvent e) {

		if ( !_alive || mange_ombrinthe ) {
			e.consume();
		}

		else {
			switch (e.getKeyCode()) {
			case KeyEvent.VK_UP:
				_orient = 0;
				break;
			case KeyEvent.VK_RIGHT:
				_orient = 1;
				break;
			case KeyEvent.VK_DOWN:
				_orient = 2;
				break;
			case KeyEvent.VK_LEFT:
				_orient = 3;
			}
			step();
		}
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
	}

	public void AllumeLanterne() {
		if (_world.tabEnvCour[_x][_y] == 3) {
			_world.tabEnvCour[_x][_y] = 2;
			_world.tabEnvNouv[_x][_y] = 2;
			sp.set_xy_case(_x, _y);
			sp.repaint();
			sp.undo_xy_case();
		}
	}

	public void die() {
		// Luminus meurt apres 0.5 seconde sur la meme case que l'ombrinthe
		
		_alive = false;
		Timer timer = new Timer();
		TimerTask task = new TimerTask() {
			public void run() {
				System.out.println("GAME OVER \n Vous etes mort au niveau "+_world.LVL+" \n"
						+ "Les Ombrinthes ont ete plus fortes que vous, mais rejouez");
				System.exit(0);
			}
		};
		timer.schedule(task, 1000);
	}
	
	public boolean bloque (){
		if(_world.tabEnvCour[_x][_y] == 6 && _bloque==0){
			_bloque=10;
			System.out.println("Vous avez glisse sur une flaque :/ \n "
					+ "Relevez-vous en appuyant 10 fois sur une fl�che. \n");
			return true;
		}
		return false;
	}

	public void kill_or_die() {
		for (int i = 0; i != _world.ombrinthesListe.size(); i++) {
			Ombrinthes o = _world.ombrinthesListe.get(i);
			if (o._alive && o.getx() == _x && o.gety() == _y) {
				if (o._digestion == 0) {
					o.mange_luminus = true;
					die();
				} else {
					//Luminus doit manger l'ombrinthe
					o.die();
				}
			}
		}
	}
	
	public void step() {
		// met a jour Luminus
		
		bloque();
		
		if(_bloque>0){
			_bloque --;
		}
		
		AllumeLanterne();
		_world.agents[_x][_y] = 0;

		// change de direction en fonction de la fleche cliquee
		deplacement();
		
		kill_or_die();
		_world.agents[_x][_y] = 1;
		sp.repeindre_morceau(_x, _y);
	}
}