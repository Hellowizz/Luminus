public class Ecosystem {


	public static boolean caseDansSalle(int xx, int yy, World w){
		for(Lanterne l : w.lanterneListe){
			if (l.getSalle().laCaseEstOccupee(xx, yy))
				return true;
		}
		return false;
	}


	public static void main(String[] args) {

		// initialisation generale

		int width = 30;  // 28 recommande
		int height = 15; // 15 recommande

		int delai = 800;

		// initialise Monde 

		World world = new World(width,height);
		Sprite s = new Sprite(world);

		// initialise trou noir

		int pos_trou_noir = (int) (Math.random()*5);
		int x_noir = 0;
		int y_noir = 0;

		switch(pos_trou_noir){   // le trou noir sera cree sur une case au hasard sur 5 emplacements possibles
		case 0:
			x_noir= width/4;
			y_noir = height/4;
			break;
		case 1:
			x_noir= 3*width/4;
			y_noir =height/4;
			break;
		case 2:
			x_noir= width/2;
			y_noir = height/2;
			break;
		case 3:
			x_noir= width/4;
			y_noir = 3*height/4;
			break;
		case 4:
			x_noir= 3*width/4;
			y_noir = 3*height/4;
			break;
		} 

		world.trou_noir = new TrouNoir(x_noir, y_noir, world);

		world.tabEnvCour[x_noir][y_noir] = 4;        // ajoute le trou noir a la matrice environnement
		world.tabEnvNouv[x_noir][y_noir] = 4;

		//initialisation des Lanternes

		int nblant = world.NB_LANTERNES;

		// initialise les 1/4 premieres Lanternes dans la zone 1

		int nblantAtraiter = nblant/4;
		int nblantRestantes = nblant - nblantAtraiter;

		for (int i =0 ; i <nblantAtraiter ; i++){      // cree une lanterne a une case totalement aleatoire sur la carte
			int x_lant = (int) (Math.random()*width/2);
			int y_lant = (int) (Math.random()*height/2);
			while(caseDansSalle(x_lant,y_lant, world) ||   // deux lanternes ne peuvent pas etres cote a cote
					world.tabEnvCour [x_lant][y_lant] != 0 || // la lanterne ne peut pas se creer sur une case qui n'est pas du sol
					world.trou_noir.laCaseEstAutour(x_lant, y_lant) ||
					x_lant <= 0 ||
					y_lant <= 0) { // la lanterne ne pourra pas être autour du trou noir
				x_lant = (int) (Math.random()*width);
				y_lant = (int) (Math.random()*height);
			}
			//System.out.println("zone 1");
			Lanterne lanterne = new Lanterne(x_lant, y_lant);
			world.add(lanterne);
		}

		// initialise les 1/3 des Lanternes restantes dans la zone 2

		nblantAtraiter = nblantRestantes/3;
		nblantRestantes = nblantRestantes - nblantAtraiter;

		for (int i =0 ; i <nblantAtraiter ; i++){      // cree une lanterne a une case totalement aleatoire sur la carte
			int x_lant = (int) (Math.random()*width);
			int y_lant = (int) (Math.random()*height/2);
			while(caseDansSalle(x_lant,y_lant, world) ||   // deux lanternes ne peuvent pas etres cote a cote
					world.tabEnvCour [x_lant][y_lant] != 0 || // la lanterne ne peut pas se creer sur une case qui n'est pas du sol
					world.trou_noir.laCaseEstAutour(x_lant, y_lant) ||
					x_lant <= width/2 ||
					y_lant <= 0) { // la lanterne ne pourra pas être autour du trou noir
				x_lant = (int) (Math.random()*width);
				y_lant = (int) (Math.random()*height);
			}
			//System.out.println("zone 2");
			Lanterne lanterne = new Lanterne(x_lant, y_lant);
			world.add(lanterne);
		}

		// initialise les 1/2 des Lanternes restantes dans la zone 3

		nblantAtraiter = nblantRestantes/2;
		nblantRestantes = nblantRestantes - nblantAtraiter;

		for (int i =0 ; i <nblantAtraiter ; i++){      // cree une lanterne a une case totalement aleatoire sur la carte
			int x_lant = (int) (Math.random()*width/2);
			int y_lant = (int) (Math.random()*height);
			while(caseDansSalle(x_lant,y_lant, world) ||   // deux lanternes ne peuvent pas etres cote a cote
					world.tabEnvCour [x_lant][y_lant] != 0 || // la lanterne ne peut pas se creer sur une case qui n'est pas du sol
					world.trou_noir.laCaseEstAutour(x_lant, y_lant) ||
					x_lant <= 0 ||
					y_lant <= height/2) { // la lanterne ne pourra pas être autour du trou noir
				x_lant = (int) (Math.random()*width);
				y_lant = (int) (Math.random()*height);
			}
			//System.out.println("zone 3");
			Lanterne lanterne = new Lanterne(x_lant, y_lant);
			world.add(lanterne);
		}

		// initialise les dernieres Lanternes restantes dans la zone 4

		nblantAtraiter = nblantRestantes;

		for (int i =0 ; i <nblantAtraiter ; i++){      // cree une lanterne a une case totalement aleatoire sur la carte
			int x_lant = (int) (Math.random()*width);
			int y_lant = (int) (Math.random()*height);
			while(caseDansSalle(x_lant,y_lant, world) ||   // deux lanternes ne peuvent pas etres cote a cote
					world.tabEnvCour [x_lant][y_lant] != 0 || // la lanterne ne peut pas se creer sur une case qui n'est pas du sol
					world.trou_noir.laCaseEstAutour(x_lant, y_lant) ||
					x_lant <= width /2||
					y_lant <= height/2) { // la lanterne ne pourra pas etre autour du trou noir
				x_lant = (int) (Math.random()*width);
				y_lant = (int) (Math.random()*height);
			}
			//System.out.println("zone 4");
			Lanterne lanterne = new Lanterne(x_lant, y_lant);
			world.add(lanterne);
		}

		Luminus lum=new Luminus(world,s);    //cree Luminus
		world.luminus = lum;
		s.frame.addKeyListener(lum);
		s.frame.requestFocus();

		world.init_flaque2();

		world.init_buisson();
		world.init_rocher();

		// mise a jour de l'etat du monde		
		while ( true )
		{		
			world.step();

			try {
				Thread.sleep(delai);
			} catch (InterruptedException e) 
			{
			}
			s.repaint();
		}
	}
}
