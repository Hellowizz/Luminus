

public class Cout {

	public double cout;
	
	// Pour le calcul du cout g et f
	public Cout(){		
	}
	
	// Pour le calcul du cout h
	public Cout(Point a,Point b){
		cout = Math.sqrt((double)( ((b.x - a.x)*(b.x - a.x)) + ((b.y - a.y)*(b.y - a.y)) ));
	}

	// Pour le calcul du cout f
	public void somme_cout(Cout a,Cout b){
		cout = a.cout + b.cout;
	}
}
