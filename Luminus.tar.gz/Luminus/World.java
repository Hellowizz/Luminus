import java.util.ArrayList;

public class World {

	// Quantitees modifiables 
	int NB_LANTERNES = 15;
	int NB_ROCHERS = 10;
	int NB_FLAQUES = 10;

	// Environnement
	int width;
	int height;
	public int[][] tabEnvCour;
	public int[][] tabEnvNouv;
	public int[][] agents;

	// variables buisson
	double densite_buiss = 0.2;
	double apparition_buiss = 0.02;
	double disparition_buiss = 0.05;

	// variables a ne pas changer
	int LVL=0;

	Sprite s;

	Luminus luminus;
	TrouNoir trou_noir;
	ArrayList<Ombrinthes> ombrinthesListe = new ArrayList<Ombrinthes>();
	ArrayList<Lanterne> lanterneListe = new ArrayList<Lanterne>();


	public World(int width, int height) {
		this.width = width;
		this.height = height;
		tabEnvCour = new int[width][height];
		tabEnvNouv = new int[width][height];
		agents = new int[width][height];
	}

	public void affiche_agents(){
		for ( int i = 0 ; i < height ; i++){
			for (int j = 0 ; j < width ; j++){
				System.out.print(agents[j][i]);
				if ( j == width - 1){
					System.out.print("\n");
				}
			}
		}
		System.out.print("\n ------------- \n");
	}

	public void affiche_action(){
		for ( int i = 0 ; i < height ; i++){
			for (int j = 0 ; j < width ; j++){
				if ( j == width - 1){
					System.out.print("\n");
				}
			}
		}
		System.out.print("\n ------------- \n");
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public void add(Object o) {
		if (o instanceof Ombrinthes) {
			ombrinthesListe.add((Ombrinthes) o);
			agents[((Ombrinthes) o).getx()][((Ombrinthes) o).gety()] = 2;
		}

		if (o instanceof Lanterne) {
			lanterneListe.add((Lanterne) o);
			tabEnvCour[((Lanterne) o).getx()][((Lanterne) o).gety()] = 3;
			tabEnvNouv[((Lanterne) o).getx()][((Lanterne) o).gety()] = 3;
		}
	}

	// FONCTIONS ENVIRONNEMENT (init buisson, etc...)

	public void init_flaque() {
		int NB_FLAQUE = 5;
		int zone = 1;
		int r_i=0, r_j=0;
		for (int i = 0; i < NB_FLAQUE; i++) {
			do {
				if (zone == 1) {
					r_i = (int) (Math.random() * (width / 2));
					r_j = (int) (Math.random() * (height / 2));
				}
				if (zone == 2){
					r_i = (int) ((Math.random() * (width / 2)) + (width / 2));
					r_j = (int) ((Math.random() * (height / 2)) + (height / 2));
				}
			}
			while (tabEnvCour[r_i][r_j] != 0 && agents[r_i][r_j] != 0); 
			zone = (zone + 1) % NB_FLAQUE + 1;
			System.out.println(zone);
			tabEnvNouv[r_i][r_j] = 6;
			tabEnvCour[r_i][r_j] = 6;
		}
	}

	public void init_rocher() {
		// etat 5 => rocher

		for(int i=0; i<NB_ROCHERS; i++){    // cree un rocher a une case totalement aleatoire sur la carte
			int x = (int) (Math.random()*width);
			int y = (int) (Math.random()*height);
			while(tabEnvCour[x][y] != 0) {   // Les rochers ne peuvent pas etre cree sur une case deja occupee
				x = (int) (Math.random()*width);
				y = (int) (Math.random()*height);
			}
			tabEnvCour[x][y] = 5;
			tabEnvNouv[x][y] = 5;
		}
	}

	public void init_flaque2() {
		// etat 6 => flaque

		for(int i=0; i<NB_FLAQUES; i++){    // cree une flaque a une case totalement aleatoire sur la carte
			int x = (int) (Math.random()*width);
			int y = (int) (Math.random()*height);
			while(tabEnvCour[x][y] != 0) {
				x = (int) (Math.random()*width);
				y = (int) (Math.random()*height);
			}
			tabEnvCour[x][y] = 6;
			tabEnvNouv[x][y] = 6;

		}
	}

	public boolean CaseVoisineEnFeu(int x, int y){
		if((x+1 < width && (tabEnvCour[x+1][y] == 14 || tabEnvCour[x+1][y] == 15)) || 
				(x-1 >= 0 && (tabEnvCour[x-1][y] == 14 || tabEnvCour[x-1][y] == 15)) ||
				(y+1 < height && (tabEnvCour[x][y+1] == 14|| tabEnvCour[x][y+1] == 15)) ||
				(y-1 >=0 && (tabEnvCour[x][y-1] == 14|| tabEnvCour[x][y-1] == 15))){
			return true;
		}
		return false;
	}

	public void leFeuEvolue(){
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				if( tabEnvCour[i][j]==14){
					tabEnvNouv[i][j]=15;
				}else{
					if( tabEnvCour[i][j]==15){
						tabEnvNouv[i][j]=16;
					}else{
						if( tabEnvCour[i][j]==16){
							tabEnvNouv[i][j]=17;
						}else{
							if( tabEnvCour[i][j]==17){
								tabEnvNouv[i][j]=0;
							}
						}
					}
				}
			}
		}
	}

	public void buissonPrendFeu(){
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				for (int l = 0; l != lanterneListe.size(); l++) {
					Lanterne lant = lanterneListe.get(l);
					if(tabEnvCour[i][j] == 1 && 
							lant.getSalle().laCaseEstOccupee(i,j) && 
							tabEnvCour[lant.x][lant.y] == 2){
						tabEnvNouv[i][j] = 14;
					}
				}
			}
		}
	}

	public void leFeuSetend(){
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				if( CaseVoisineEnFeu(i,j) && tabEnvCour[i][j] == 1){
					tabEnvNouv[i][j] = 14;
				}
			}
		}
	}

	public void init_buisson() {

		// Etat 0 => sol par defaut
		// Etat 1 => buisson

		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				// verification de l absence d un agent a cette coordonnee
				if (tabEnvCour[i][j] == 0 && agents[i][j] == 0) {
					double r = Math.random();
					if (r <= densite_buiss) {
						tabEnvCour[i][j] = 1;
						tabEnvNouv[i][j] = 1;
					} else {
						tabEnvCour[i][j] = 0;
						tabEnvNouv[i][j] = 0;
					}
				}
			}
		}
	}

	public void en_apparition_buiss() {
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				double r = Math.random();
				if (tabEnvCour[i][j] == 0 && agents[i][j] == 0) {
					if (r <= apparition_buiss) {
						tabEnvNouv[i][j] = 12;
					}
				}
			}

		}
	}

	public void apparition_buiss() {
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				if (tabEnvCour[i][j] == 12) {
					tabEnvNouv[i][j] = 1;
				}
			}
		}
	}

	public void en_disparition_buiss() {
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				double r = Math.random();
				if (tabEnvCour[i][j] == 1) {
					if (r <= disparition_buiss) {
						tabEnvNouv[i][j] = 13;
					}
				}
			}
		}
	}

	public void disparition_buiss() {
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				if (tabEnvCour[i][j] == 13) {
					tabEnvNouv[i][j] = 0;
				}
			}
		}
	}

	public void stepWorld() { // world THEN agents
		leFeuEvolue();
		leFeuSetend();
		en_apparition_buiss();
		apparition_buiss();
		en_disparition_buiss();
		disparition_buiss();
		buissonPrendFeu();

		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				tabEnvCour[i][j] = tabEnvNouv[i][j];
			}
		}
	}

	public void stepAgents() { // world THEN agents

		ArrayList<Agent> aSupprimer = new ArrayList<Agent>();

		if (Ombrinthes.getCompteurTotal() > 0) {
			trou_noir.creerOmbrinthesRandom();
		}

		if (Ombrinthes.getCompteurTotal() == 0){
			LVL ++;
			System.out.println("Niveau : "+LVL+"\n");
			trou_noir.recreerOmbrinthes(LVL);
		}

		for (int i = 0; i != ombrinthesListe.size(); i++) {
			Ombrinthes o = ombrinthesListe.get(i);

			if ( o._alive ){
				o.step();
			}
			else {
				aSupprimer.add(o);
			}
		}

		for (int i = 0; i != aSupprimer.size(); i++) {
			Ombrinthes o = (Ombrinthes) aSupprimer.get(i);
			ombrinthesListe.remove(o);
		}
	}

	public void step() {
		stepWorld();
		stepAgents();
	}

}
