public class Point {
	
	// Coordonnees d'une case
	public int x;
	public int y;
	
	public Point(int i,int j){
		x = i;
		y = j;
	}
}
