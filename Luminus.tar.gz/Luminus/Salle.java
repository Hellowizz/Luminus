public class Salle {
	private int [][] casesOccupees;
	private Lanterne lant;
	
	public Lanterne getLant() {
		return lant;
	}

	public Salle(Lanterne l){
		lant = l;
		casesOccupees = new int[2][9];
		
		casesOccupees[0][0]=(l.x-1);
		casesOccupees[1][0]=(l.y-1);
		
		casesOccupees[0][1]=(l.x);
		casesOccupees[1][1]=(l.y-1);
		
		casesOccupees[0][2]=(l.x+1);
		casesOccupees[1][2]=(l.y-1);
	
		casesOccupees[0][3]=(l.x-1);
		casesOccupees[1][3]=(l.y);
		
		casesOccupees[0][4]=(l.x);
		casesOccupees[1][4]=(l.y);
		
		casesOccupees[0][5]=(l.x+1);
		casesOccupees[1][5]=(l.y);
		
		casesOccupees[0][6]=(l.x-1);
		casesOccupees[1][6]=(l.y+1);
		
		casesOccupees[0][7]=(l.x);
		casesOccupees[1][7]=(l.y+1);
		
		casesOccupees[0][8]=(l.x+1);
		casesOccupees[1][8]=(l.y+1);
	}
	
	public int [][] getCasesOcuppees(){
		return casesOccupees;
	}
	
	public boolean laCaseEstOccupee( int x, int y){
		for(int i=0; i<9; i++){
			if(casesOccupees[0][i] == x && casesOccupees[1][i]==y){
				return true;
			}
		}
		return false;
	}
}
