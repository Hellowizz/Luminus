public class Lanterne {

	int x;
	int y;
	private static int nombre_allumee=0;
	private int numero;
	private Salle salle;
	
	// Quand la lanterne est allumee, une ombrinthe se chargera de l'eteindre
	boolean marquee_par_ombrinthe;

	public Lanterne (int _x, int _y){
		x = _x;
		y = _y;
		salle = new Salle(this);
		marquee_par_ombrinthe = false;
	}
	
	public Salle getSalle(){
		return salle;
	} 

	public int getNumero(){
		return numero;
	}

	public int getNbAllumee(){
		return nombre_allumee;
	}
	
	public int getx(){
		return x;
	}
	
	public int gety(){
		return y;
	}
}