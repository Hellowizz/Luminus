import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Sprite extends JPanel {

	private static final long serialVersionUID = 1L;
	public JFrame frame;
	private BufferedImage solSprite;

	private int spriteLength = 40;
	private World w;

	private BufferedImage BuissonSprite1;
	private BufferedImage BuissonSprite2;
	private BufferedImage BuissonSpriteFeu;
	private BufferedImage BuissonSpriteFeu2;
	private BufferedImage BuissonSpriteFeu3;
	private BufferedImage BuissonSpriteFeu4;

	private BufferedImage lanterne1Sprite;
	private BufferedImage lanterneEteinteSprite;
	private BufferedImage TrouNoirSprite;
	private BufferedImage RocherSprite;
	private BufferedImage FlaqueSprite;

	private BufferedImage LuminusFaceSprite1;
	private BufferedImage LuminusDroiteSprite1;
	private BufferedImage LuminusGaucheSprite1;

	private BufferedImage OmbrintheFaceSprite1;
	private BufferedImage OmbrintheDroiteSprite1;
	private BufferedImage OmbrintheGaucheSprite1;

	private BufferedImage DigestionFaceSprite1;
	private BufferedImage DigestionDroiteSprite1;
	private BufferedImage DigestionGaucheSprite1;

	// variables permettant de "repeindre" qu'une zone
	// pour eviter de "repeindre" toute la map a chaque deplacement de Luminus
	int x_case, y_case;

	public Sprite(World w) {
		this.w = w;
		x_case = -1;
		y_case = -1;
		try {
			FlaqueSprite = ImageIO.read(new File("eau.png"));
			RocherSprite = ImageIO.read(new File("Rocher.png"));
			TrouNoirSprite = ImageIO.read(new File("Trou_noir.png"));
			solSprite = ImageIO.read(new File("sol.png"));

			BuissonSprite1 = ImageIO.read(new File("Buisson_1.png"));
			BuissonSprite2 = ImageIO.read(new File("Buisson_2.png"));
			BuissonSpriteFeu = ImageIO.read(new File("Feu.png"));
			BuissonSpriteFeu2 = ImageIO.read(new File("Feu2.png"));
			BuissonSpriteFeu3 = ImageIO.read(new File("Feu3.png"));
			BuissonSpriteFeu4 = ImageIO.read(new File("Feu4.png"));

			lanterne1Sprite = ImageIO.read(new File("Lanterne_allumee_01.png"));
			lanterneEteinteSprite = ImageIO.read(new File("Lanterne_eteinte.png"));

			LuminusFaceSprite1 = ImageIO.read(new File("Luminus_Face_1.png"));
			LuminusDroiteSprite1 = ImageIO.read(new File("Luminus_Droite1.png"));
			LuminusGaucheSprite1 = ImageIO.read(new File("Luminus_Gauche1.png"));

			OmbrintheFaceSprite1 = ImageIO.read(new File("Ombrinthe_Face_01.png"));
			OmbrintheDroiteSprite1 = ImageIO.read(new File("Ombrinthe_Droite_01.png"));
			OmbrintheGaucheSprite1 = ImageIO.read(new File("Ombrinthe_Gauche_01.png"));

			DigestionFaceSprite1 = ImageIO.read(new File("Digestion_Face1.png"));
			DigestionDroiteSprite1 = ImageIO.read(new File("Digestion_Droite1.png"));
			DigestionGaucheSprite1 = ImageIO.read(new File("Digestion_Gauche1.png"));

		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit(2);
		}
		frame = new JFrame("Luminus");
		frame.add(this);
		frame.setSize(w.width*spriteLength+6, w.height*spriteLength+28);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public void set_xy_case(int i, int j) {
		x_case = i;
		y_case = j;
	}

	public void undo_xy_case() {
		x_case = -1;
		y_case = -1;
	}

	public void repeindre_morceau(int i, int j) {
		set_xy_case(i, j);
		repaint();
		undo_xy_case();
	}

	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		int x_min, x_max, y_min, y_max;

		if (x_case != -1 && y_case != -1) {
			x_min = x_case - 1;
			x_max = x_case + 2;
			y_min = y_case - 1;
			y_max = y_case + 2;
		} else {
			x_min = 0;
			x_max = w.width;
			y_min = 0;
			y_max = w.height;
		}
		for (int i = x_min; i < x_max; i++) {
			for (int j = y_min; j < y_max; j++) {

				switch (w.tabEnvCour[i][j]) {
				case 0:
					g2.drawImage(solSprite, spriteLength * i, spriteLength * j,
							spriteLength, spriteLength, frame);
					break;
				case 1:
					g2.drawImage(BuissonSprite1, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				case 2:
					g2.drawImage(lanterne1Sprite, spriteLength * i,
							spriteLength * j, spriteLength, spriteLength, frame);
					break;
				case 3:
					g2.drawImage(lanterneEteinteSprite, spriteLength * i,
							spriteLength * j, spriteLength, spriteLength, frame);
					break;
				case 4:
					g2.drawImage(TrouNoirSprite, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				case 5:
					g2.drawImage(RocherSprite, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				case 6:
					g2.drawImage(FlaqueSprite, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				case 12:
					g2.drawImage(BuissonSprite2, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				case 13:
					g2.drawImage(BuissonSprite2, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				case 14:
					g2.drawImage(BuissonSpriteFeu, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				case 15:
					g2.drawImage(BuissonSpriteFeu2, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				case 16:
					g2.drawImage(BuissonSpriteFeu3, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				case 17:
					g2.drawImage(BuissonSpriteFeu4, spriteLength * i, spriteLength
							* j, spriteLength, spriteLength, frame);
					break;
				}
			}
		}

		// afichage de Luminus
		Luminus Lum = w.luminus;

		switch (Lum._orient) {
		case 0: // nord
			g2.drawImage(LuminusFaceSprite1, spriteLength * Lum._x,
					spriteLength * Lum._y, spriteLength, spriteLength, frame);
			break;
		case 1: // est
			g2.drawImage(LuminusGaucheSprite1, spriteLength * Lum._x,
					spriteLength * Lum._y, spriteLength, spriteLength, frame);
			break;
		case 2: // sud
			g2.drawImage(LuminusFaceSprite1, spriteLength * Lum._x,
					spriteLength * Lum._y, spriteLength, spriteLength, frame);

			break;
		case 3: // ouest
			g2.drawImage(LuminusDroiteSprite1, spriteLength * Lum._x,
					spriteLength * Lum._y, spriteLength, spriteLength, frame);
			break;
		}

		for (int h = 0; h != w.ombrinthesListe.size(); h++) {
			Ombrinthes ombra = w.ombrinthesListe.get(h);

			switch (ombra._orient) {
			case 0: // nord
				if (ombra._digestion == 0) {
					g2.drawImage(OmbrintheFaceSprite1, spriteLength * ombra._x,
							spriteLength * ombra._y, spriteLength,
							spriteLength, frame);
				} else {
					g2.drawImage(DigestionFaceSprite1, spriteLength * ombra._x,
							spriteLength * ombra._y, spriteLength,
							spriteLength, frame);
				}
				break;
			case 1: // est
				if (ombra._digestion == 0) {
					g2.drawImage(OmbrintheDroiteSprite1, spriteLength
							* ombra._x, spriteLength * ombra._y, spriteLength,
							spriteLength, frame);
				} else {
					g2.drawImage(DigestionDroiteSprite1, spriteLength
							* ombra._x, spriteLength * ombra._y, spriteLength,
							spriteLength, frame);
				}
				break;
			case 2: // sud
				if (ombra._digestion == 0) {
					g2.drawImage(OmbrintheFaceSprite1, spriteLength * ombra._x,
							spriteLength * ombra._y, spriteLength,
							spriteLength, frame);
				} else {
					g2.drawImage(DigestionFaceSprite1, spriteLength * ombra._x,
							spriteLength * ombra._y, spriteLength,
							spriteLength, frame);
				}
				break;
			case 3: // ouest
				if (ombra._digestion == 0) {
					g2.drawImage(OmbrintheGaucheSprite1, spriteLength
							* ombra._x, spriteLength * ombra._y, spriteLength,
							spriteLength, frame);
				} else {
					g2.drawImage(DigestionGaucheSprite1, spriteLength
							* ombra._x, spriteLength * ombra._y, spriteLength,
							spriteLength, frame);
				}
				break;
			}

		}
	}
}
