import java.util.ArrayList; 

public class Astar {

	public World world;
	public Point depart;
	public Point arrivee;

	public ArrayList<Noeud> liste_ouverte;
	public ArrayList<Noeud> liste_fermee;
	public Point[] coord;

	public Astar(World w,Point d,Point a){
		world = w;
		depart = d;
		arrivee = a;

		liste_ouverte = new ArrayList<Noeud>();
		liste_fermee = new ArrayList<Noeud>();
		coord = new Point[4];
	}

	public boolean present_dans_liste(ArrayList<Noeud> liste, Noeud n){

		for(int i = 0; i < liste.size(); i++){
			if ( comparaison_noeud(liste.get(i),n) ){
				return true;
			}
		}		
		return false;
	}

	public boolean comparaison_noeud(Noeud a,Noeud b){
		// Renvoie vrai si 2 noeuds ont les memes coordonnees
		if ( a.courant.x == b.courant.x && a.courant.y == b.courant.y ){
			return true;
		}
		return false;
	}

	public int ajout_dans_liste(Noeud n){

		for(int i = 0; i < liste_ouverte.size(); i++){
			if ( comparaison_noeud(liste_ouverte.get(i),n) ){
				if ( liste_ouverte.get(i).f.cout > n.f.cout){
					// Mettre a jour la liste ouverte : remplacer le noeud par n
					return i;
				}
				else{
					return -2;
				}
			}
		}
		return -1;
	}

	public Noeud meilleur_noeud(ArrayList<Noeud> liste){

		Noeud n = liste.get(0);
		for(int i = 0; i < liste.size(); i++){
			if ( n.f.cout > liste.get(i).f.cout ){
				n = liste.get(i);
			}
		}
		return n;
	}

	public boolean[][] construire_chemin(Noeud n){
		boolean c = true;
		boolean[][] chemin = new boolean[world.width][world.height];
		chemin[depart.x][depart.y] = true;
		Noeud n_c = n;
		while ( c ){
			chemin[n_c.courant.x][n_c.courant.y] = true;
			n_c = n_c.parent;
			if ( n_c.parent == null ) c = false;
		}
		return chemin;
	}

	public boolean obstacle(int i,int j){
		return world.tabEnvCour[i][j] == 1 || world.tabEnvCour[i][j] == 5 || world.tabEnvCour[i][j] == 14 ||
				world.tabEnvCour[i][j] == 15 || world.tabEnvCour[i][j] == 16;
	}

	public boolean en_dehors(int i,int j){
		return i < 0 || i >= world.width || j < 0 || j >= world.height;
	}

	public void ajouter_voisin(Noeud n){

		coord[0] = new Point(n.courant.x - 1, n.courant.y);
		coord[1] = new Point(n.courant.x, n.courant.y - 1);
		coord[2] = new Point(n.courant.x, n.courant.y + 1);
		coord[3] = new Point(n.courant.x + 1, n.courant.y);

		for(int i = 0; i < 4; i++){

			if ( !en_dehors(coord[i].x,coord[i].y) && !obstacle(coord[i].x,coord[i].y) ){

				Noeud voisin = new Noeud(n,new Point(coord[i].x,coord[i].y));
				if (!present_dans_liste(liste_fermee,voisin)){

					// Calcul du cout g
					voisin.g = new Cout();
					voisin.g.cout = n.g.cout + 1;

					// Calcul du cout h
					voisin.h = new Cout(voisin.courant,arrivee);

					// Calcul du cout f
					voisin.f = new Cout();
					voisin.f.somme_cout(voisin.h, voisin.g);

					// Ajout du noeud dans la liste ouverte s'il n'est pas present dans celle-ci avec un meilleur cout
					if ( present_dans_liste(liste_ouverte,voisin) ){	

						int q = ajout_dans_liste(voisin);
						if ( q > 0 ){
							liste_ouverte.remove(q);
							liste_ouverte.add(q,voisin);
							n.nbVoisinVerif++;
						}
						if ( q == -1 ){
							liste_ouverte.add(voisin);
							n.nbVoisinVerif++;
						}
						if ( q == -2 ){
						}
					}
					else{
						liste_ouverte.add(voisin);
						n.nbVoisinVerif++;
					}
				}
			}
		}
		if ( n.nbVoisinVerif == 0 ){
			liste_ouverte.remove(n);
		}
	}

	public void ajouter_liste_fermee(Noeud n){
		liste_ouverte.remove(liste_ouverte.indexOf(n));
		liste_fermee.add(n);
	}

	public boolean[][] astar_final(){
		boolean c = true;
		Noeud n_courant = new Noeud(null,depart);
		n_courant.h = new Cout(depart,arrivee);
		n_courant.f = new Cout();
		n_courant.f.cout = n_courant.h.cout;

		liste_ouverte.add(n_courant);
		ajouter_liste_fermee(n_courant);
		ajouter_voisin(n_courant);

		while ( c && !liste_ouverte.isEmpty() ){		
			n_courant = meilleur_noeud(liste_ouverte);
			ajouter_liste_fermee(n_courant);
			ajouter_voisin(n_courant);
			if ( n_courant.courant.x == arrivee.x && n_courant.courant.y  == arrivee.y ){
				c = false;
			}
		}

		if ( n_courant.courant.x == arrivee.x && n_courant.courant.y == arrivee.y ){
			return construire_chemin(n_courant);
		}
		else{
			return null;
		}
	}
}
