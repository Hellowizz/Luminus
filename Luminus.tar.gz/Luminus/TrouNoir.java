public class TrouNoir{

	private int x;
	private int y;
	private int compteurOmbrinthes;
	private double pourcentCreerOmbrinthe = 0.1;
	private World world;

	public TrouNoir(int _x, int _y, World w){
		x = _x;
		y = _y;
		world = w;
	}

	public void recreerOmbrinthes(int nb){
		compteurOmbrinthes = nb;
		creerOmbrinthes();
	}

	public void creerOmbrinthesRandom(){
		double pourcent = Math.random();
		if(pourcent<pourcentCreerOmbrinthe && compteurOmbrinthes > 0){
			Ombrinthes o = new Ombrinthes(world);
			world.add(o);
			this.compteurOmbrinthes --;
			pourcentCreerOmbrinthe = 0.1;
		}else{
			pourcentCreerOmbrinthe += 0.1;
			return;
		}
	}

	public void creerOmbrinthes(){
		Ombrinthes o = new Ombrinthes(world);
		this.compteurOmbrinthes --;
		world.add(o);
	}

	public boolean laCaseEstAutour(int _x, int _y){
		boolean test = false;

		for(int i=-1; i<2 ; i++){
			for(int j=-1; j<2; j++){
				if(_x==x+i && _y==y+j){
					test = true;
				}
			}
		}

		return test;
	} 

	public int getx(){
		return x;
	}

	public int gety(){
		return y;
	}

	public int getCompteurOmbrinthes(){
		return compteurOmbrinthes;
	}
}
