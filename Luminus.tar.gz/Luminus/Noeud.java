

public class Noeud{

	public Point courant;
	public Noeud parent;
	public int nbVoisinVerif;
	
	// depart -> noeud etudie
	Cout g;
	
	// noeud etudie -> arrivee
	Cout h;
	
	// g + h
	Cout f;
	
	public Noeud(Noeud p,Point cour) {
		parent = p;
		courant = cour;
		g = new Cout();
		nbVoisinVerif = 0;
	}
}
